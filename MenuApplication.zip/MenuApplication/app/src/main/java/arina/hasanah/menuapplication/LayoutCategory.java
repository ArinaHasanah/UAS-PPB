package lucky.mumpuni.menuapplication;

public class LayoutCategory {
}
