package arina.hasanah.menuapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MakananActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_makanan)
    }
}